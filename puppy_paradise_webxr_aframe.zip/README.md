Puppy Paradise — WebXR A-Frame Starter
======================================

How to use
---------
1. Upload the folder to a static host (Netlify, Vercel, GitHub Pages) or host locally and open the index.html with a WebXR-capable browser (Quest Browser).
2. Open the page and tap "Enter VR".
3. Touch walls/geometry with your controllers and make a pushing motion away from the surface to propel the player (Gorilla Tag style).
4. Tweak parameters in `main.js` (pushStrength, maxSpeed, damping) to adjust feel.

Files
-----
- index.html : A-Frame scene and placeholders.
- main.js    : Movement system (push-movement A-Frame system).
- README.md  : This file.

Notes & next steps
------------------
- This is a prototype system using simple raycasts and velocity integration — not a full physics simulation.
- For more stable/realistic movement consider adding cannon.js ammo.js physics, or use character controllers.
- Replace the placeholder puppy with a glTF model and attach it to the rig.
- Add multiplayer using WebRTC / Colyseus / Socket.io for shared play.
- If you want, I can expand this into a full demo with a GLTF puppy, multiplayer, and deployment-ready files.
