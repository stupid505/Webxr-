// main.js - Gorilla Tag style push locomotion for A-Frame
AFRAME.registerSystem('push-movement', {
  init: function () {
    this.rig = document.querySelector('#rig');
    this.left = document.querySelector('#leftHand');
    this.right = document.querySelector('#rightHand');
    this.camera = document.querySelector('#camera');

    // movement state
    this.velocity = new THREE.Vector3(0, 0, 0);
    this.grounded = false;

    // tuneable params
    this.pushStrength = 5.0;      // impulse multiplier
    this.maxSpeed = 6.0;          // meters per second
    this.damping = 0.92;          // per-frame damping for velocity
    this.contactDistance = 0.12;  // how close a hand must be to be "touching"
    this.contactDotThreshold = 0.3; // dot threshold for push direction

    // previous hand positions
    this.prevLeft = new THREE.Vector3();
    this.prevRight = new THREE.Vector3();

    // temp vectors
    this._handPos = new THREE.Vector3();
    this._handVel = new THREE.Vector3();
    this._hitNormal = new THREE.Vector3();
    this._tmp = new THREE.Vector3();
  },

  tick: function (time, delta) {
    delta = delta / 1000; // to seconds
    if (!this.rig) return;

    const leftObj = this.left.object3D;
    const rightObj = this.right.object3D;
    const rigObj = this.rig.object3D;

    // update prev positions on first frame
    if (this.prevLeft.lengthSq() === 0) this.prevLeft.copy(leftObj.getWorldPosition(this._handPos));
    if (this.prevRight.lengthSq() === 0) this.prevRight.copy(rightObj.getWorldPosition(this._handPos));

    // compute hand velocities (world space)
    const curLeft = leftObj.getWorldPosition(this._handPos.clone());
    const curRight = rightObj.getWorldPosition(this._handPos.clone());
    const leftVel = curLeft.clone().sub(this.prevLeft).divideScalar(Math.max(delta, 0.0001));
    const rightVel = curRight.clone().sub(this.prevRight).divideScalar(Math.max(delta, 0.0001));

    // check hands for contact and pushing
    this.handleHandPush(curLeft, leftVel, delta);
    this.handleHandPush(curRight, rightVel, delta);

    // integrate velocity into rig position (simple physics)
    // gravity-like small downward effect to keep grounded feeling
    this.velocity.y -= 9.8 * delta * 0.1; // reduced gravity for floaty feel

    // apply damping
    this.velocity.multiplyScalar(this.damping);

    // clamp horizontal speed
    const horiz = this.velocity.clone();
    horiz.y = 0;
    if (horiz.length() > this.maxSpeed) {
      horiz.setLength(this.maxSpeed);
      this.velocity.x = horiz.x;
      this.velocity.z = horiz.z;
    }

    // apply to rig position
    rigObj.position.x += this.velocity.x * delta;
    rigObj.position.y += this.velocity.y * delta;
    rigObj.position.z += this.velocity.z * delta;

    // prevent falling below floor (simple ground collision)
    if (rigObj.position.y < 0.9) {
      rigObj.position.y = 0.9;
      this.velocity.y = Math.max(0, this.velocity.y);
      this.grounded = true;
    } else {
      this.grounded = false;
    }

    // save prevs
    this.prevLeft.copy(curLeft);
    this.prevRight.copy(curRight);
  },

  handleHandPush: function (handPos, handVel, delta) {
    // perform a short spherecast (approx with three.js raycaster and bounding sphere)
    const scene = this.el.sceneEl.object3D;
    const origin = handPos.clone();
    const dir = handVel.clone();
    if (dir.length() < 0.01) return; // not moving enough

    dir.normalize();
    const maxDist = this.contactDistance + 0.05;

    // Raycast against visible objects
    const raycaster = new THREE.Raycaster(origin, dir, 0, maxDist);
    const intersects = raycaster.intersectObjects(scene.children, true);

    if (intersects.length === 0) return;

    // find first usable hit that is not the hand or camera or rig
    let hit = null;
    for (let i = 0; i < intersects.length; i++) {
      const obj = intersects[i].object;
      if (obj.el && (obj.el.id === 'leftHand' || obj.el.id === 'rightHand' || obj.el.id === 'camera' || obj.el.id === 'rig')) {
        continue;
      }
      hit = intersects[i];
      break;
    }
    if (!hit) return;

    // compute dot between hand velocity and hit normal (we want pushing INTO surface)
    const normal = hit.face ? hit.face.normal.clone().applyMatrix4(hit.object.matrixWorld).normalize() : new THREE.Vector3(0,1,0);
    const dot = handVel.clone().normalize().dot(normal);

    // only apply impulse if pushing into the surface (dot > threshold)
    if (dot > this.contactDotThreshold) {
      // impulse direction is opposite normal
      const impulseDir = normal.clone().multiplyScalar(-1);

      // magnitude based on hand speed and configured strength
      const speed = handVel.length();
      const mag = speed * this.pushStrength * 0.01; // scaling down to match scene scale

      // add impulse to velocity (world space)
      this.velocity.add( impulseDir.multiplyScalar(mag) );

      // small upward nudge to simulate jump-from-push
      this.velocity.y += 0.2 * Math.min(1.0, speed * 0.02);

      // optional: haptics (if available)
      this.tryHaptics(hit);
    }
  },

  tryHaptics: function (hit) {
    // best-effort: send haptic pulse to any input source near the hit (works in compatible browsers)
    const sources = this.el.sceneEl.renderer.xr.getSession()?.inputSources || [];
    sources.forEach(src => {
      if (src.gamepad && src.hapticActuators && src.hapticActuators.length) {
        try {
          src.hapticActuators[0].pulse(0.2, 50);
        } catch (e) {
          // ignore failures
        }
      }
    });
  }
});
